﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Blog.Models
{
    public class Comment
    {

        [Column("id")]
        public int CommentId { get; set; }

        public int PostId { get; set; }

        public string AuthorName { get; set; } = "";

        public string Content { get; set; } = "";

        public DateTime CreatedAt { get; set; }= DateTime.Now;

        [ForeignKey("PostId")]
        public Post? Post { get; set; }
    }
}
