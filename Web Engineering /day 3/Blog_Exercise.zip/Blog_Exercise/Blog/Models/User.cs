﻿using System.ComponentModel.DataAnnotations;

namespace Blog.Models
{
    public class User
    {

        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string UserName { get; set; } = "";

        [Required]
        [EmailAddress]
        [StringLength(256)]
        public string Email { get; set; } = "";

        [Required]
        public string PasswordHash { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        
    }
}
