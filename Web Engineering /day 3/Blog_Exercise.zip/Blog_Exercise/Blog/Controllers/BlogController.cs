﻿using Blog.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Blog.Controllers
{
    public class BlogController : Controller
    {

        private readonly BlogContext _db;
        public BlogController(BlogContext ctx) { 
            this._db = ctx;
        }
        public IActionResult Index()
        {
            List<Post> posts = this._db.Posts.ToList();
            ViewBag.Posts = posts;
            
            return View();
        }

        [Route("/Posts/{id}")]
        public IActionResult Single(int id)
        {
            Post? post = this._db.Posts.Where(p => p.Id == id).Include(p => p.Comments).FirstOrDefault();
            ViewBag.Post = post;
            return View();
        }

        [Authorize]
        [HttpPost("/Posts/{id}/comment")]
        public IActionResult Comment(int id,Comment c)
        {

            c.PostId = id;
            this._db.Comments.Add(c);
            this._db.SaveChanges();
            return RedirectToAction("Single", "Blog", new { id=id});
        }

        [Authorize]
        [HttpGet("/Posts/create")]
        public IActionResult Create()
        {
            return View();
        }


    }
}
