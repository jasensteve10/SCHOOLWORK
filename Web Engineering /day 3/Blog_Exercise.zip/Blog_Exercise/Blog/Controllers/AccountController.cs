﻿using Blog.Controllers.Filter;
using Blog.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Blog.Controllers
{
    public class AccountController : Controller
    {
        private readonly BlogContext _db;
        private readonly PasswordHasher<User> _passwordHasher = new PasswordHasher<User>();


        public AccountController(BlogContext ctx)
        {
            this._db = ctx;
        }

        [GuestOnly]
        [HttpGet("/register")]
        public IActionResult Register()
        {
            return View();
        }

        [GuestOnly]
        [HttpPost("/register")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RegisterProcess(RegisterViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            bool emailExists = await this._db.Users.AnyAsync(u => u.Email == model.Email);
            bool userNameExists = await this._db.Users.AnyAsync(u => u.UserName == model.UserName);

            if (emailExists)
            {
                ModelState.AddModelError(nameof(model.Email), "This email is already registred");
            }

            if (userNameExists)
            {
                ModelState.AddModelError(nameof(model.UserName), "This username is already taken");
            }

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            User user = new User
            {
                UserName = model.UserName,
                Email = model.Email,
                CreatedAt = DateTime.Now,
            };

            user.PasswordHash = this._passwordHasher.HashPassword(user, model.Password);
            this._db.Users.Add(user);
            await this._db.SaveChangesAsync();

            return RedirectToAction("Login", "Account");


        }
        [GuestOnly]
        [HttpGet("/login")]
        public IActionResult Login()
        {
            
            return View();
        }

        [GuestOnly]
        [HttpPost("/login")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> LoginProcess(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            //Another way to use linq
            User? user = this._db.Users.FirstOrDefault(u => u.Email == model.Email);

            if (user == null)
            {
                ModelState.AddModelError("", "Invalid email or password.");
                return View(model);
            }

            PasswordVerificationResult result = this._passwordHasher.VerifyHashedPassword(user, user.PasswordHash, model.Password);

            if (result == PasswordVerificationResult.Failed)
            {
                ModelState.AddModelError("", "Invalid email or password.");
                return View(model);
            }

            await SignInUser(user);

            return RedirectToAction("Index", "Blog");

        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Blog");
        }


        private async Task SignInUser(User user)
        {
            List<Claim> claims = new List<Claim>()
            {
                new Claim(ClaimTypes.NameIdentifier,user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.UserName),
                new Claim(ClaimTypes.Email,user.Email)
            };

            ClaimsIdentity identity= new ClaimsIdentity(claims,CookieAuthenticationDefaults.AuthenticationScheme);
            ClaimsPrincipal principal = new ClaimsPrincipal(identity);

            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal) ;
        }

    }
}
