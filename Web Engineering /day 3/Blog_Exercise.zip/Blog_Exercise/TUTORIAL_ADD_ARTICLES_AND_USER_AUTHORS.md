# Tutorial: Add Articles, Comments, and Logged-In Authors

This tutorial enhances the existing Blog MVC application so students can:

- Create a new blog article.
- Save the logged-in user as the author of a post.
- Save the logged-in user as the author of a comment.
- Stop asking users to type their name manually.

The application already has `Post`, `Comment`, `BlogContext`, `BlogController`, and two views:

- `Models/Post.cs`
- `Models/Comment.cs`
- `Models/BlogContext.cs`
- `Controllers/BlogController.cs`
- `Views/Blog/Index.cshtml`
- `Views/Blog/Single.cshtml`

This guide assumes you will add register, login, and logout separately. Once authentication is available, the important rule is:

> The browser form should not decide who the author is. The server should use the currently logged-in user.

## Goal

At the end, the blog should work like this:

1. A visitor can read all posts.
2. A logged-in user can create a new article.
3. A logged-in user can comment on an article.
4. The post author and comment author come from the authenticated user, not from a form field.

## Step 1: Prepare The Models For Authenticated Authors

Right now, both `Post` and `Comment` store this:

```csharp
public string AuthorName { get; set; } = "";
```

That works before authentication, but once login/register exists, it is better to keep both:

- `AuthorId`: the stable user id from the authentication system.
- `AuthorName`: the display name or email shown in the UI.

Update `Models/Post.cs`:

```csharp
namespace Blog.Models
{
    public class Post
    {
        public int Id { get; set; }

        public string Title { get; set; } = "";

        public string Content { get; set; } = "";

        public string AuthorId { get; set; } = "";

        public string AuthorName { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public List<Comment> Comments { get; set; } = new List<Comment>();
    }
}
```

Update `Models/Comment.cs`:

```csharp
using System.ComponentModel.DataAnnotations.Schema;

namespace Blog.Models
{
    public class Comment
    {
        [Column("id")]
        public int CommentId { get; set; }

        public int PostId { get; set; }

        public string AuthorId { get; set; } = "";

        public string AuthorName { get; set; } = "";

        public string Content { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [ForeignKey("PostId")]
        public Post? Post { get; set; }
    }
}
```

## Step 2: Add A View Model For Creating Articles

Do not bind the full `Post` entity directly from the form. The form only needs a title and content.

Create a new file:

`Models/CreatePostViewModel.cs`

```csharp
using System.ComponentModel.DataAnnotations;

namespace Blog.Models
{
    public class CreatePostViewModel
    {
        [Required]
        [StringLength(120)]
        public string Title { get; set; } = "";

        [Required]
        public string Content { get; set; } = "";
    }
}
```

Why use a view model?

- Students only expose the fields the user is allowed to submit.
- The user cannot fake `AuthorName`, `AuthorId`, or `CreatedAt`.
- Validation becomes easier.

## Step 3: Add A Create Page In The Controller

Open `Controllers/BlogController.cs`.

Add these `using` statements:

```csharp
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
```

Then add two actions to `BlogController`.

```csharp
[Authorize]
[HttpGet]
public IActionResult Create()
{
    return View();
}

[Authorize]
[HttpPost]
[ValidateAntiForgeryToken]
public IActionResult Create(CreatePostViewModel model)
{
    if (!ModelState.IsValid)
    {
        return View(model);
    }

    var authorId = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "";
    var authorName = User.Identity?.Name ?? "Unknown user";

    var post = new Post
    {
        Title = model.Title,
        Content = model.Content,
        AuthorId = authorId,
        AuthorName = authorName,
        CreatedAt = DateTime.Now
    };

    _db.Posts.Add(post);
    _db.SaveChanges();

    return RedirectToAction("Single", "Blog", new { id = post.Id });
}
```

Important detail:

```csharp
var authorId = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "";
var authorName = User.Identity?.Name ?? "Unknown user";
```

This is the line that connects the article to the logged-in user.

## Step 4: Create The Article Form View

Create a new file:

`Views/Blog/Create.cshtml`

```cshtml
@model Blog.Models.CreatePostViewModel

@{
    ViewData["Title"] = "Create Article";
}

<div class="container py-5">
    <div class="mb-4">
        <h1 class="fw-bold">Create Article</h1>
        <p class="text-muted">Write a new post for the blog.</p>
    </div>

    <form asp-controller="Blog" asp-action="Create" method="post" class="card shadow-sm">
        <div class="card-body">
            <div asp-validation-summary="ModelOnly" class="text-danger mb-3"></div>

            <div class="mb-3">
                <label asp-for="Title" class="form-label"></label>
                <input asp-for="Title" class="form-control" />
                <span asp-validation-for="Title" class="text-danger"></span>
            </div>

            <div class="mb-3">
                <label asp-for="Content" class="form-label"></label>
                <textarea asp-for="Content" class="form-control" rows="10"></textarea>
                <span asp-validation-for="Content" class="text-danger"></span>
            </div>

            <button type="submit" class="btn btn-primary">
                Publish
            </button>

            <a asp-controller="Blog" asp-action="Index" class="btn btn-outline-secondary">
                Cancel
            </a>
        </div>
    </form>
</div>

@section Scripts {
    <partial name="_ValidationScriptsPartial" />
}
```

## Step 5: Add A Link To Create An Article

Open `Views/Blog/Index.cshtml`.

Inside the top section, add a button. Only show it to authenticated users:

```cshtml
<div class="mb-4 d-flex justify-content-between align-items-center">
    <div>
        <h1 class="fw-bold">Blog Posts</h1>
        <p class="text-muted">Read the latest posts from our blog.</p>
    </div>

    @if (User.Identity?.IsAuthenticated == true)
    {
        <a asp-controller="Blog"
           asp-action="Create"
           class="btn btn-primary">
            New Article
        </a>
    }
</div>
```

If the user is not logged in, they can still read posts, but they cannot create one.

## Step 6: Update Comments To Use The Logged-In User

Right now, the comment form asks for:

```html
Your Name
```

After authentication, remove that input. The server already knows who the user is.

In `Controllers/BlogController.cs`, update the comment action:

```csharp
[Authorize]
[HttpPost("/Posts/{id}/comment")]
[ValidateAntiForgeryToken]
public IActionResult Comment(int id, Comment c)
{
    var postExists = _db.Posts.Any(p => p.Id == id);

    if (!postExists)
    {
        return NotFound();
    }

    c.PostId = id;
    c.AuthorId = User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "";
    c.AuthorName = User.Identity?.Name ?? "Unknown user";
    c.CreatedAt = DateTime.Now;

    _db.Comments.Add(c);
    _db.SaveChanges();

    return RedirectToAction("Single", "Blog", new { id = id });
}
```

The form still sends the comment `Content`, but it no longer sends the author.

## Step 7: Update The Comment Form View

Open `Views/Blog/Single.cshtml`.

Replace the current "Add Comment" section with this version:

```cshtml
@if (User.Identity?.IsAuthenticated == true)
{
    <section class="card shadow-sm mt-4">
        <div class="card-header bg-white">
            <h3 class="mb-0">Add Comment</h3>
        </div>

        <div class="card-body">
            <form asp-controller="Blog"
                  asp-action="Comment"
                  asp-route-id="@post.Id"
                  method="post">

                <div class="mb-3">
                    <label class="form-label">
                        Comment
                    </label>

                    <textarea name="Content"
                              class="form-control"
                              rows="5"
                              required></textarea>
                </div>

                <button type="submit" class="btn btn-primary">
                    Post Comment
                </button>
            </form>
        </div>
    </section>
}
else
{
    <div class="alert alert-secondary mt-4">
        Please log in to add a comment.
    </div>
}
```

## Step 8: Make Sure Authentication Middleware Is In The Right Place

After you add register/login/logout, `Program.cs` should include authentication services and middleware.

The middleware order should be:

```csharp
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();
```

`UseAuthentication()` must run before `UseAuthorization()`.

## Step 9: Add A Database Migration

Because `Post` and `Comment` now have `AuthorId`, create a migration.

From the project folder:

```powershell
cd Blog
dotnet ef migrations add AddAuthorIdToPostsAndComments
dotnet ef database update
```

If `dotnet ef` is not installed, install the Entity Framework tool:

```powershell
dotnet tool install --global dotnet-ef
```

Then run the migration commands again.

## Step 10: Expected Final Behavior

Test these scenarios:

1. Log out.
2. Open the blog home page.
3. Confirm you can read posts.
4. Confirm the "New Article" button is hidden.
5. Open a single post.
6. Confirm the comment form is hidden and a login message appears.
7. Register or log in.
8. Confirm the "New Article" button appears.
9. Create a new article.
10. Confirm the article displays your username or email as the author.
11. Add a comment.
12. Confirm the comment displays your username or email as the author.

## Suggested Student Exercise

After the basic version works, ask students to improve it:

- Show the newest posts first:

```csharp
List<Post> posts = _db.Posts
    .OrderByDescending(p => p.CreatedAt)
    .ToList();
```

- Show the newest comments first:

```csharp
Post? post = _db.Posts
    .Where(p => p.Id == id)
    .Include(p => p.Comments.OrderByDescending(c => c.CreatedAt))
    .FirstOrDefault();
```

- Add a maximum length to comments.
- Allow only the original author to edit or delete their own post.
- Allow only the original author to delete their own comment.
