using System.ComponentModel.DataAnnotations;

namespace Blog.Models
{
    // This ViewModel keeps comment submission simple and controlled.
    public class AddCommentViewModel
    {
        [Required]
        [StringLength(500)]
        public string Content { get; set; } = "";
    }
}
