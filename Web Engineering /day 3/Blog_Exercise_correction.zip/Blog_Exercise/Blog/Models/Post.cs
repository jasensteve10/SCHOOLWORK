﻿namespace Blog.Models
{
    // A Post is one article written by a registered user.
    public class Post
    {

        public int Id { get; set; }

        public string Title { get; set; } = "";

        public string Content { get; set; } = "";

        public int AuthorId { get; set; }

        public string AuthorName { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // Navigation properties let EF Core connect posts, comments, and users.
        public List<Comment> Comments { get; set; } = new List<Comment>();

        public User? Author { get; set; }
    }
}
