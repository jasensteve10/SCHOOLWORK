﻿using System.ComponentModel.DataAnnotations;

namespace Blog.Models
{
    // A User is the account saved after registration.
    public class User
    {

        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string UserName { get; set; } = "";

        [Required]
        [EmailAddress]
        [StringLength(256)]
        public string Email { get; set; } = "";

        [Required]
        // Store the hashed password, never the plain password.
        public string PasswordHash { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        
    }
}
