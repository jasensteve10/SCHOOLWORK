﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Blog.Models
{
    // A Comment belongs to one post and one author.
    public class Comment
    {

        // The SQL column is named "id", but the C# property is clearer here.
        [Column("id")]
        public int CommentId { get; set; }

        public int PostId { get; set; }

        public int AuthorId { get; set; }

        public string AuthorName { get; set; } = "";

        public string Content { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        // These references help EF Core understand the relationships.
        [ForeignKey("PostId")]
        public Post? Post { get; set; }

        public User? Author { get; set; }
    }
}
