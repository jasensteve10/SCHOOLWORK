namespace Blog.Models
{
    // This model shows a request id only when ASP.NET gives us one.
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
