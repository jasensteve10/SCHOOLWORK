﻿using Microsoft.EntityFrameworkCore;

namespace Blog.Models
{
    // This class tells EF Core which tables exist in the blog database.
    public class BlogContext : DbContext
    {

        public BlogContext (DbContextOptions<BlogContext> options) : base(options) { }

        public DbSet<Post> Posts { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<User> Users { get; set; }
    }
}
