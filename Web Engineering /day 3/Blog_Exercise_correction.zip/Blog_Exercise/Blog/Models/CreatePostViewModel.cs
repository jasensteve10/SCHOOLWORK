using System.ComponentModel.DataAnnotations;

namespace Blog.Models
{
    // This ViewModel exposes only the fields needed to create or edit a post.
    public class CreatePostViewModel
    {
        [Required]
        [StringLength(120)]
        public string Title { get; set; } = "";

        [Required]
        public string Content { get; set; } = "";
    }
}
