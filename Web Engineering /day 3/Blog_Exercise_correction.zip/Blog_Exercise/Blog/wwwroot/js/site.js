// Shared JavaScript file for small blog-wide behaviors.
