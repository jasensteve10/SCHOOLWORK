﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Blog.Controllers.Filter
{
    public class GuestOnlyAttribute : ActionFilterAttribute
    {


        public override void OnActionExecuting(ActionExecutingContext context)
        {
            // Logged-in users should not return to login/register pages.
            if (context.HttpContext.User.Identity != null &&
            context.HttpContext.User.Identity.IsAuthenticated)
            {
                context.Result = new RedirectToActionResult(
                    "Index",
                    "Blog",
                    null
                );
            }

            base.OnActionExecuting(context);
        }

    }
}
