﻿using Blog.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace Blog.Controllers
{
    public class BlogController : Controller
    {

        // The blog controller reads and writes posts/comments through EF Core.
        private readonly BlogContext _db;
        public BlogController(BlogContext ctx) { 
            this._db = ctx;
        }
        public IActionResult Index()
        {
            // Load all posts for the home page list.
            List<Post> posts = this._db.Posts.ToList();
            ViewBag.Posts = posts;
            
            return View();
        }

        [Route("/Posts/{id}")]
        public IActionResult Single(int id)
        {
            // Include comments so the detail page has everything it needs.
            Post? post = this._db.Posts.Where(p => p.Id == id).Include(p => p.Comments).FirstOrDefault();
            ViewBag.Post = post;
            return View();
        }

        [Authorize]
        [HttpPost("/Posts/{id}/comment")]
        [ValidateAntiForgeryToken]
        public IActionResult Comment(int id, AddCommentViewModel model)
        {
            // A comment must belong to an existing post.
            bool postExists = this._db.Posts.Any(p => p.Id == id);

            if (!postExists)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                // TempData survives the redirect, so the view can show the error.
                TempData["CommentError"] = "Comments are required and must be 500 characters or fewer.";
                return RedirectToAction("Single", "Blog", new { id = id });
            }

            // The author comes from the logged-in user, not from the form.
            Comment c = new Comment
            {
                PostId = id,
                AuthorId = GetCurrentUserId(),
                AuthorName = User.Identity?.Name ?? "",
                Content = model.Content,
                CreatedAt = DateTime.Now
            };

            this._db.Comments.Add(c);
            this._db.SaveChanges();

            return RedirectToAction("Single", "Blog", new { id = id });
        }




        [Authorize]
        [HttpGet("/Posts/create")]
        public IActionResult Create()
        {
            return View();
        }


        [Authorize]
        [HttpPost("/Posts/create")]
        [ValidateAntiForgeryToken]
        public IActionResult Create(CreatePostViewModel model)
        {
            // The ViewModel keeps the form limited to title and content.
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            int authorId = GetCurrentUserId();
            string authorName = User.Identity?.Name ?? "";

            Post post = new Post
            {
                Title = model.Title,
                Content = model.Content,
                AuthorId = authorId,
                AuthorName = authorName,
                CreatedAt = DateTime.Now
            };

            this._db.Posts.Add(post);
            this._db.SaveChanges();

            return RedirectToAction("Single", "Blog", new { id = post.Id });
        }

        [Authorize]
        [HttpGet("/Posts/{id}/edit")]
        public IActionResult Edit(int id)
        {
            Post? post = this._db.Posts.FirstOrDefault(p => p.Id == id);

            if (post == null)
            {
                return NotFound();
            }

            if (post.AuthorId != GetCurrentUserId())
            {
                // Only the original author can edit their own article.
                return Forbid();
            }

            CreatePostViewModel model = new CreatePostViewModel
            {
                Title = post.Title,
                Content = post.Content
            };

            ViewBag.PostId = post.Id;
            return View(model);
        }

        [Authorize]
        [HttpPost("/Posts/{id}/edit")]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, CreatePostViewModel model)
        {
            Post? post = this._db.Posts.FirstOrDefault(p => p.Id == id);

            if (post == null)
            {
                return NotFound();
            }

            if (post.AuthorId != GetCurrentUserId())
            {
                // We repeat the check on POST because users can fake requests.
                return Forbid();
            }

            if (!ModelState.IsValid)
            {
                ViewBag.PostId = post.Id;
                return View(model);
            }

            post.Title = model.Title;
            post.Content = model.Content;

            this._db.SaveChanges();

            return RedirectToAction("Single", "Blog", new { id = post.Id });
        }

        [Authorize]
        [HttpPost("/Comments/{id}/delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteComment(int id)
        {
            Comment? comment = this._db.Comments.FirstOrDefault(c => c.CommentId == id);

            if (comment == null)
            {
                return NotFound();
            }

            if (comment.AuthorId != GetCurrentUserId())
            {
                // Same protection: only the comment author can delete it.
                return Forbid();
            }

            int postId = comment.PostId;

            this._db.Comments.Remove(comment);
            this._db.SaveChanges();

            return RedirectToAction("Single", "Blog", new { id = postId });
        }

        [HttpPost("/Posts/{id}/delete")]
        public IActionResult DeletePost(int id)
        {
            Post? post = this._db.Posts.FirstOrDefault(p => p.Id == id);

            if (post == null)
            {
                return NotFound();
            }

            if (post.AuthorId != GetCurrentUserId())
            {
                // We repeat the check on POST because users can fake requests.
                return Forbid();
            }

            this._db.Posts.Remove(post);
            this._db.SaveChanges(true);

            return RedirectToAction("Index", "Blog");
        }

        private int GetCurrentUserId()
        {
            // The user id is stored in the auth cookie as a claim.
            string? userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            if (!int.TryParse(userId, out int id))
            {
                throw new InvalidOperationException("The logged-in user id is missing.");
            }

            return id;
        }

    }
}
