var author=null;
var lastUpdate=null;
var message_sent=null;
var api ="replace_by_your_api_base_url"
var api_key=""
$('#startTchat').click(function(){
	

		//Login here with email password and add token to api key variable you will be able to use it later
		//Then call function below when you got the token to start the chat
		$('#nameInput').hide();
		$('#tchat').show();
		lastUpdate=0;
		updateMessages();
	
});

var tchatbox=$('#message-box');


$('#send').click(function(){
	var text = $('#message').val()
	if(text){
		$('#message').val('');
		sendMessage(author,text);
	}
});

function sendMessage(sender,message){
	//Write here the function to get send a message to the good route then when sent to api works 
	//use sentMessage to sentMessage to add message in html chat
}

function buildMessage(sender,created_at,content){
	var color= author == sender ? 'orange' : 'blue';
	var result ='<div class="message-'+color+'">'+'<p class="message-content">'+content+'</p>'+'<div class="message-timestamp-left">'+sender+' '+created_at+'</div>'+'</div>';
    return result;
}

function updateMessages(){
	//Write here the part to get last message from your api, you can use the DisplayMessage function to add it to the chat

	setTimeout(updateMessages,15000);
}

function displayNewMessage(data){
	for (var i = 0; i < data.length; i++) {
		if(data[i].id == message_sent){
			continue;
		}
		tchatbox.append(buildMessage(data[i].username,data[i].createdAt,data[i].content));
	}
	if(data.length>0){
		lastUpdate=data[data.length-1].id;
	}
	
}


function sentMessage(data){
	message_sent= data.id;
	tchatbox.append(buildMessage(data.username,data.createdAt,data.content));
}
