﻿using System.ComponentModel.DataAnnotations;

namespace BookStore.DTO
{
    public class LoginRequest
    {

        [Required]
        [EmailAddress]
        public string Email { get; set; } = default!;

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; } = default!;
    }
}
