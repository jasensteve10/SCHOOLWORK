﻿using System.ComponentModel.DataAnnotations;

namespace BookStore.DTO
{
    public class RegisterUser
    {
        [Required]
        [StringLength(255)]
        [EmailAddress]
        public string Email { get; set; } = "";

        [Required]
        [DataType(DataType.Password)]
        [MinLength(6)]
        public string Password { get; set; } = "";

        [Required]
        [DataType(DataType.Password)]
        [Compare("Password")]
        public string ConfirmPassword { get; set; } = "";
    }
}
