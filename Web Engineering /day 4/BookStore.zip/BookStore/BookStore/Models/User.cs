﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace BookStore.Models
{

    public enum Role { Customer = 0, Admin = 1}
    public class User
    {

        public int Id { get; set; }

        public string Email { get; set; } = default!;

        [JsonIgnore]
        public string PasswordHash { get; set; } = "";

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        
        public Role Role { get; set; }=Role.Customer;


        public ICollection<Comment> Comments { get; set; } = new List<Comment>();

        public ICollection<Order> Orders { get; set;  } = new List<Order>();

    }
}
