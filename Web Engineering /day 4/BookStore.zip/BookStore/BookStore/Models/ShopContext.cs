﻿using Microsoft.EntityFrameworkCore;

namespace BookStore.Models
{
    public class ShopContext :DbContext
    {

        public ShopContext(DbContextOptions<ShopContext> options):base(options) { }
        
        protected override void OnModelCreating(ModelBuilder b)
        {
            base.OnModelCreating(b);

            // ----- Users -----
            b.Entity<User>()
                .HasIndex(u => u.Email)
                .IsUnique();

            // Store Role enum as string ("Customer"/"Admin")
            b.Entity<User>()
                .Property(u => u.Role)
                .HasConversion<string>();

            // ----- Books -----
            b.Entity<Book>()
                .Property(x => x.Price)
                .HasColumnType("decimal(10,2)");

            b.Entity<Book>()
                .HasIndex(x => x.Genre);


            // ----- Orders -----
            b.Entity<Order>()
                .HasOne(o => o.User)
                .WithMany(u => u.Orders)
                .HasForeignKey(o => o.UserId)
                .OnDelete(DeleteBehavior.Cascade);

            // ----- OrderItems -----
            b.Entity<OrderItem>()
                .HasOne(oi => oi.Order)
                .WithMany(o => o.Items)
                .HasForeignKey(oi => oi.OrderId)
                .OnDelete(DeleteBehavior.Cascade);

            // We keep order history: do not delete a Book if it has order lines
            b.Entity<OrderItem>()
                .HasOne(oi => oi.Book)
                .WithMany() // no back-collection required on Book
                .HasForeignKey(oi => oi.BookId)
                .OnDelete(DeleteBehavior.Restrict);

            // One book per order line (no duplicates in the same order)
            b.Entity<OrderItem>()
                .HasIndex(oi => new { oi.OrderId, oi.BookId })
                .IsUnique();

            b.Entity<OrderItem>()
                .Property(oi => oi.UnitPrice)
                .HasColumnType("decimal(10,2)");

            // Computed column persisted in SQL: LineTotal = Quantity * UnitPrice
            b.Entity<OrderItem>()
                .Property(oi => oi.LineTotal)
                .HasColumnType("decimal(10,2)")
                .HasComputedColumnSql("[Quantity] * [UnitPrice]", stored: true);

            // ----- Comments -----
            b.Entity<Comment>()
                .HasOne(c => c.Book)
                .WithMany(bk => bk.Comments)
                .HasForeignKey(c => c.BookId)
                .OnDelete(DeleteBehavior.Cascade);

            // If a user is deleted, keep the comment but null the user ref
            b.Entity<Comment>()
                .HasOne(c => c.User)
                .WithMany(u => u.Comments)
                .HasForeignKey(c => c.UserId)
                .OnDelete(DeleteBehavior.SetNull);
        }


        public DbSet<Book> Books { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set;  }
    }
}
