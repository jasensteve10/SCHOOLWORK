﻿using System.Text.Json.Serialization;

namespace BookStore.Models
{
    public class Comment
    {
        public int Id { get; set; }

        public byte? Rating { get; set; }

        public string Body { get; set; } = default!;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Book
        public int BookId { get; set; }

        public Book Book { get; set; } = default!;

        //User

        public int UserId { get; set; }

        public User User { get; set; } = default!;
    }
}
