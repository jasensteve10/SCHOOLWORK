﻿namespace BookStore.Models
{
    public class Order
    {
        public int Id { get; set; }

        public string Status { get; set; } = "Pending";

        public DateTime CreatedAt { get; set; }=DateTime.Now;

        public decimal Amount { get; set; } //Compute Order

        public ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();

        public int UserId { get; set; }

        public User User { get; set; } = default!;
    }
}
