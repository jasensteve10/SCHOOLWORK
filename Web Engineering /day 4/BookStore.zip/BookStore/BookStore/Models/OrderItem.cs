﻿namespace BookStore.Models
{
    public class OrderItem
    {
        public int Id { get; set; }

        public int Quantity { get; set; }

        public decimal UnitPrice { get; set; }

        public decimal LineTotal { get; set; }


        //Order

        public int OrderId { get; set; }

        public Order Order { get; set; } = default!;

        //Book

        public int BookId { get; set; }

        public Book Book { get; set; } = default!;
    }
}
