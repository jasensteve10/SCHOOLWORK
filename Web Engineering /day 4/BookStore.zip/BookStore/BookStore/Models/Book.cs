﻿namespace BookStore.Models
{
    public class Book
    {

        public int Id { get; set; }

        public string Title { get; set; } = "";

        public string Description { get; set; } = "";

        public string Author { get; set; } = "";

        public string Genre { get; set; } = "";

        public decimal Price { get; set; }

        public DateTime DateWritten { get; set; }

        public ICollection<Comment> Comments { get; set; } = new List<Comment>();

        public ICollection<OrderItem> OrderItems = new List<OrderItem>();
    }
}
