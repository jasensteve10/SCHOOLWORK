﻿using BookStore.DTO;
using BookStore.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : ControllerBase
    {

        private readonly ShopContext _db;
        private readonly PasswordHasher<User> _passwordHasher = new PasswordHasher<User>();

        public UsersController(ShopContext db) { _db= db; }


        [HttpGet("")]
        [Authorize(Roles ="Admin")]
        public ActionResult<ICollection<User>> GetAll()
        {
            try
            {
                return Ok(_db.Users.ToList());
            }
            catch (Exception ex)
            {
                return Problem(
                        title: "Internal Server Error",
                        detail: ex.Message,
                        statusCode: 500
                    );

            }
        }

        [HttpPost("")]
        public async Task<ActionResult> Register([FromBody] RegisterUser rgister)
        {

            if (!ModelState.IsValid) {
                return BadRequest("Invalid register request");
            }
            try
            {


                bool emailExists = await this._db.Users.AnyAsync(u => u.Email == rgister.Email);

                if (emailExists)
                {
                    return Problem(
                    title: "Not Acceptable",
                    detail: "User with this email already exists",
                    statusCode: 406
                );
                }

                User user = new User
                {
                    Email = rgister.Email,
                    CreatedAt = DateTime.Now,
                };

                // We never store the real password, only its hash.
                user.PasswordHash = this._passwordHasher.HashPassword(user, rgister.Password);
                this._db.Users.Add(user);
                await this._db.SaveChangesAsync();
                return Ok(new {
                    message="ok"
                });
            }
            catch (Exception ex) {
                return Problem(
                        title: "Internal Server Error",
                        detail: ex.Message,
                        statusCode: 500
                    );
            }
        }


    }
}
