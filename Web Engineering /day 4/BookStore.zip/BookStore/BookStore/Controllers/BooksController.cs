﻿using BookStore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {

        private readonly ShopContext _db;

        public BooksController(ShopContext db)
        {
            _db = db;
        }

        //GET /api/books
        [HttpGet("")]
        public ActionResult<ICollection<Book>> GetAll()
        {
            try
            {
                return _db.Books.ToList();
            }
            catch(Exception e)
            {
                return Problem(
                        title: "Internal Server Error",
                        detail: e.Message,
                        statusCode: 500
                    );
            }
        }

        //GET api/books/{id}
        [HttpGet("{id}")]
        public ActionResult<Book> Get(int id)
        {
            try
            {
                Book? res = _db.Books.FirstOrDefault(b => b.Id == id);
                if(res is null)
                {
                    return NotFound();
                }
                return Ok(res);
            }
            catch(Exception e)
            {
                return Problem(
                       title: "Internal Server Error",
                       detail: e.Message,
                       statusCode: 500
                   );
            }
        }
        //POST api/books
        [HttpPost("")]
        public ActionResult<Book> Create([FromBody] Book b)
        {
            try
            {
                this._db.Books.Add(b);
                this._db.SaveChanges();
                return Ok(b);
            }
            catch (Exception e)
            {
                return Problem(
                       title: "Internal Server Error",
                       detail: e.Message,
                       statusCode: 500
                   );
            }
        }

        // PUT api/books/id
        [HttpPut("{id}")]
        public ActionResult<Book> Update(int id, [FromBody] Book b)
        {
            try
            {
                Book? res = _db.Books.FirstOrDefault(b => b.Id == id);
                if (res is null)
                {
                    return NotFound();
                }
                b.Id=id;
                _db.Books.Add(b);
                _db.SaveChanges();
                return Ok(b);
            }
            catch (Exception e)
            {
                return Problem(
                       title: "Internal Server Error",
                       detail: e.Message,
                       statusCode: 500
                   );
            }
        }

        //DELETE api/books/id
        [HttpDelete("{id}")]
        public ActionResult<Book> Delete(int id)
        {
            try
            {
                Book? res = _db.Books.FirstOrDefault(b => b.Id == id);
                if (res is null)
                {
                    return NotFound();
                }
                _db.Books.Remove(res);
                _db.SaveChanges();
                return Ok(res);
            }
            catch (Exception e)
            {
                return Problem(
                       title: "Internal Server Error",
                       detail: e.Message,
                       statusCode: 500
                   );
            }
        }

        //Comments
        [HttpGet("{id}/comments")]
        public ActionResult<ICollection<Comment>> GetComments(int id)
        {
            try
            {
                Book? res = _db.Books.Include( b=> b.Comments).FirstOrDefault(b => b.Id == id);
                if (res is null)
                {
                    return NotFound();
                }
                return Ok(res.Comments);
            }
            catch (Exception e)
            {
                return Problem(
                       title: "Internal Server Error",
                       detail: e.Message,
                       statusCode: 500
                   );
            }
        }

        [HttpDelete("{bookid}/comments/{id}")]
        public ActionResult<Comment> DeleteComment(int bookid, int id)
        {
            try
            {
                Comment? res = _db.Comments.FirstOrDefault(c => c.Id == id && c.BookId == bookid);
                if (res is null)
                {
                    return NotFound();
                }
                _db.Comments.Remove(res);
                _db.SaveChanges();
                return Ok(res);
            }
            catch (Exception e)
            {
                return Problem(
                       title: "Internal Server Error",
                       detail: e.Message,
                       statusCode: 500
                   );
            }
        }

        [HttpPost("{id}/comments")]
        public ActionResult<Comment> CreateComment(int id, [FromBody] Comment c)
        {
            try
            {
                Book? res = _db.Books.FirstOrDefault(b => b.Id == id);
                if (res is null)
                {
                    return NotFound();
                }
                this._db.Comments.Add(c);
                this._db.SaveChanges();
                return Ok(c);
            }
            catch (Exception e)
            {
                return Problem(
                       title: "Internal Server Error",
                       detail: e.Message,
                       statusCode: 500
                   );
            }
        }


    }
}
