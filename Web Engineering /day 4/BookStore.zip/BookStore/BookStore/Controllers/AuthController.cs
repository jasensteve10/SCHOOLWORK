﻿using BookStore.Auth;
using BookStore.DTO;
using BookStore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BookStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly ShopContext _db;
        private readonly JwtSettings _jwt;
        private readonly PasswordHasher<User> _passwordHasher = new PasswordHasher<User>();

        public AuthController(ShopContext db, IOptions<JwtSettings> jwt)
        {
            this._db = db;
            this._jwt = jwt.Value;
        }

        // api/auth/login
        [HttpPost("login")]
        public async Task<ActionResult<object>> Login([FromBody] LoginRequest request)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(new { message = "Email and password are required." });
            }

            User? user = await _db.Users.FirstOrDefaultAsync(u => u.Email == request.Email);

            if (user is null)
            {
                return Unauthorized(new { message = "Invalid email or password." });
            }
            PasswordVerificationResult result = this._passwordHasher.VerifyHashedPassword(user, user.PasswordHash, request.Password);
            if (result == PasswordVerificationResult.Failed)
            {
                return Unauthorized(new { message = "Invalid email or password." });
            }
            DateTime expiresAt = DateTime.UtcNow.AddMinutes(_jwt.ExpiresMinutes);
            SymmetricSecurityKey key = new(Encoding.UTF8.GetBytes(_jwt.Key));
            SigningCredentials credentials = new(key, SecurityAlgorithms.HmacSha256);

            Claim[] claims =
            [
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.Email, user.Email),
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.Email),
                new Claim(ClaimTypes.Role, user.Role.ToString())
            ];

            JwtSecurityToken token = new(
                issuer: _jwt.Issuer,
                audience: _jwt.Audience,
                claims: claims,
                expires: expiresAt,
                signingCredentials: credentials);

            return Ok(new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                token_type = "Bearer",
                expires_at = expiresAt,
                user = new
                {
                    user.Id,
                    user.Email,
                    role = user.Role.ToString()
                }
            });

        }
    }
}
