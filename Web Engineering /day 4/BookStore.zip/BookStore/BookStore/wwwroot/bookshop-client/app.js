﻿// App state
const state = {
    apiBase: normalizeApiBase(localStorage.getItem("bookstoreApiBase") || window.location.origin),
    books: [],
    selectedBookId: null,
    cart: readCart(),
    auth: readAuth()
};

const coverColors = ["#45624e", "#9a4c3c", "#317179", "#405d8a", "#9c6b2d", "#5e527f", "#6f6b3d"];

// DOM elements
const els = {
    apiBaseInput: document.querySelector("#apiBaseInput"),
    saveApiButton: document.querySelector("#saveApiButton"),
    refreshButton: document.querySelector("#refreshButton"),
    statusStrip: document.querySelector("#statusStrip"),
    searchInput: document.querySelector("#searchInput"),
    genreFilter: document.querySelector("#genreFilter"),
    sortSelect: document.querySelector("#sortSelect"),
    bookGrid: document.querySelector("#bookGrid"),
    catalogCount: document.querySelector("#catalogCount"),
    detailPanel: document.querySelector("#detailPanel"),
    cartList: document.querySelector("#cartList"),
    cartCount: document.querySelector("#cartCount"),
    cartTotal: document.querySelector("#cartTotal"),
    clearCartButton: document.querySelector("#clearCartButton"),
    checkoutButton: document.querySelector("#checkoutButton"),
    bookForm: document.querySelector("#bookForm"),
    loginForm: document.querySelector("#loginForm"),
    authStatus: document.querySelector("#authStatus"),
    logoutButton: document.querySelector("#logoutButton"),
    cardTemplate: document.querySelector("#bookCardTemplate")
};

els.apiBaseInput.value = state.apiBase;
document.querySelector("#dateInput").valueAsDate = new Date();

// API base config
els.saveApiButton.addEventListener("click", () => {
    state.apiBase = normalizeApiBase(els.apiBaseInput.value);
    els.apiBaseInput.value = state.apiBase;
    localStorage.setItem("bookstoreApiBase", state.apiBase);
    loadBooks();
});

els.refreshButton.addEventListener("click", loadBooks);
els.searchInput.addEventListener("input", renderCatalog);
els.genreFilter.addEventListener("change", renderCatalog);
els.sortSelect.addEventListener("change", renderCatalog);

// Cart events
els.clearCartButton.addEventListener("click", () => {
    state.cart = {};
    persistCart();
    renderCart();
});

els.checkoutButton.addEventListener("click", () => {
    const count = Object.values(state.cart).reduce((sum, item) => sum + item.quantity, 0);
    if (!count) {
        setStatus("Your cart is empty.", "error");
        return;
    }

    setStatus("Checkout preview ready. The current API has no order creation endpoint yet.", "success");
});

// Login event
els.loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const form = new FormData(els.loginForm);
    const payload = {
        email: String(form.get("email") || "").trim(),
        password: String(form.get("password") || "")
    };

    try {
        setStatus("Signing in...");
        const result = await apiFetch("/api/auth/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        state.auth = {
            token: result.token,
            tokenType: result.token_type || "Bearer",
            expiresAt: result.expires_at,
            user: result.user
        };
        localStorage.setItem("bookstoreAuth", JSON.stringify(state.auth));
        els.loginForm.reset();
        renderAuth();
        setStatus(`Signed in as ${state.auth.user.email}.`, "success");
    } catch (error) {
        setStatus(error.message, "error");
    }
});

// Logout event
els.logoutButton.addEventListener("click", () => {
    state.auth = null;
    localStorage.removeItem("bookstoreAuth");
    renderAuth();
    setStatus("Signed out.", "success");
});

// Admin book create
els.bookForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    if (!isAdmin()) {
        setStatus("An admin bearer token is required to add books.", "error");
        return;
    }

    const form = new FormData(els.bookForm);
    const payload = {
        title: cleanString(form.get("title")),
        author: cleanString(form.get("author")),
        genre: cleanString(form.get("genre")),
        description: cleanString(form.get("description")),
        price: form.get("price") ? Number(form.get("price")) : null,
        published_date: new Date(form.get("dateWritten")).toISOString()
    };

    try {
        setStatus("Adding book...");
        const created = await apiFetch("/api/books", {
            method: "POST",
            auth: true,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        els.bookForm.reset();
        document.querySelector("#dateInput").valueAsDate = new Date();
        setStatus(`Added "${created.title || "Untitled"}".`, "success");
        await loadBooks(false);
        state.selectedBookId = created.id;
        renderDetail(created);
    } catch (error) {
        setStatus(error.message, "error");
    }
});

loadBooks();
renderCart();
renderAuth();

// Load books from API
async function loadBooks(showLoading = true) {
    if (showLoading) {
        setStatus("Loading catalog...");
    }

    try {
        state.books = await apiFetch("/api/books");
        populateGenres();
        renderCatalog();
        renderCart();
        setStatus(`Connected to ${state.apiBase}.`, "success");
    } catch (error) {
        state.books = [];
        renderCatalog();
        renderCart();
        setStatus(error.message, "error");
    }
}

// Render catalog cards
function renderCatalog() {
    const books = filteredBooks();
    els.bookGrid.replaceChildren();
    els.catalogCount.textContent = `${books.length} ${books.length === 1 ? "book" : "books"} available`;

    if (!books.length) {
        const empty = document.createElement("div");
        empty.className = "empty-state";
        empty.textContent = "No books match the current filters.";
        els.bookGrid.append(empty);
        return;
    }

    for (const book of books) {
        const node = els.cardTemplate.content.firstElementChild.cloneNode(true);
        const button = node.querySelector(".book-select");
        const cover = node.querySelector(".book-cover");

        cover.style.setProperty("--cover-color", coverColor(book));
        node.querySelector(".cover-title").textContent = book.title || "Untitled";
        node.querySelector(".cover-author").textContent = book.author || "Unknown author";
        node.querySelector(".book-title").textContent = book.title || "Untitled";
        node.querySelector(".book-author").textContent = book.author || "Unknown author";
        node.querySelector(".book-genre").textContent = book.genre || "Unsorted";
        node.querySelector(".book-price").textContent = formatMoney(book.price);

        button.addEventListener("click", () => selectBook(book.id));
        els.bookGrid.append(node);
    }
}

// Select one book
async function selectBook(id) {
    state.selectedBookId = id;
    const cached = state.books.find((book) => book.id === id);
    if (cached) {
        renderDetail(cached);
    }

    try {
        const fresh = await apiFetch(`/api/books/${id}`);
        state.books = state.books.map((book) => book.id === id ? { ...book, ...fresh } : book);
        renderDetail(fresh);
    } catch (error) {
        setStatus(error.message, "error");
    }
}

// Render book details
function renderDetail(book) {
    const comments = Array.isArray(book.comments) ? book.comments : [];
    const wrapper = document.createElement("div");
    wrapper.className = "detail-layout";
    wrapper.innerHTML = `
    <span class="book-cover" aria-hidden="true" style="--cover-color: ${coverColor(book)}">
      <span class="cover-band"></span>
      <span class="cover-title">${escapeHtml(book.title || "Untitled")}</span>
      <span class="cover-author">${escapeHtml(book.author || "Unknown author")}</span>
    </span>
    <div>
      <h2 class="detail-title">${escapeHtml(book.title || "Untitled")}</h2>
      <p class="detail-subtitle">${escapeHtml(book.author || "Unknown author")}</p>
      <p class="detail-description">${escapeHtml(book.description || "No description has been added yet.")}</p>
    </div>
    <div class="detail-facts">
      <div class="fact"><span>Genre</span><strong>${escapeHtml(book.genre || "Unsorted")}</strong></div>
      <div class="fact"><span>Price</span><strong>${formatMoney(book.price)}</strong></div>
      <div class="fact"><span>Published</span><strong>${formatDate(book.dateWritten)}</strong></div>
      <div class="fact"><span>Comments</span><strong>${comments.length}</strong></div>
    </div>
    <div class="detail-actions">
      <button class="primary-button" type="button" data-action="add">Add to cart</button>
      <button class="ghost-button" type="button" data-action="delete">Delete</button>
    </div>
    <div>
      <h3>Reader comments</h3>
      <div class="comment-list"></div>
    </div>
  `;

    wrapper.querySelector('[data-action="add"]').addEventListener("click", () => addToCart(book));
    wrapper.querySelector('[data-action="delete"]').addEventListener("click", () => deleteBook(book));

    const list = wrapper.querySelector(".comment-list");
    if (!comments.length) {
        const empty = document.createElement("p");
        empty.className = "comment-body";
        empty.textContent = "No comments yet.";
        list.append(empty);
    } else {
        for (const comment of comments) {
            const item = document.createElement("article");
            item.className = "comment-item";
            item.innerHTML = `
        <strong>${comment.rating ? `${comment.rating}/5` : "Unrated"}</strong>
        <p class="comment-body">${escapeHtml(comment.body || "")}</p>
      `;
            list.append(item);
        }
    }

    els.detailPanel.replaceChildren(wrapper);
}

// Delete book from API
async function deleteBook(book) {
    const confirmed = window.confirm(`Delete "${book.title || "Untitled"}" from the API?`);
    if (!confirmed) {
        return;
    }

    if (!isAdmin()) {
        setStatus("An admin bearer token is required to delete books.", "error");
        return;
    }

    try {
        await apiFetch(`/api/books/${book.id}`, { method: "DELETE", auth: true });
        delete state.cart[book.id];
        persistCart();
        state.selectedBookId = null;
        setStatus(`Deleted "${book.title || "Untitled"}".`, "success");
        await loadBooks(false);
        renderEmptyDetail();
    } catch (error) {
        setStatus(error.message, "error");
    }
}

// Reset detail panel
function renderEmptyDetail() {
    els.detailPanel.innerHTML = `
    <div class="empty-detail">
      <span class="empty-cover" aria-hidden="true"></span>
      <h2>Select a book</h2>
      <p>Book details, comments, and buying controls will appear here.</p>
    </div>
  `;
}

// Add book to cart
function addToCart(book) {
    const id = String(book.id);
    const existing = state.cart[id] || {
        id: book.id,
        title: book.title || "Untitled",
        price: Number(book.price || 0),
        quantity: 0
    };

    existing.quantity += 1;
    existing.price = Number(book.price || 0);
    state.cart[id] = existing;
    persistCart();
    renderCart();
    setStatus(`Added "${existing.title}" to cart.`, "success");
}

// Render local cart
function renderCart() {
    const items = Object.values(state.cart);
    els.cartList.replaceChildren();

    const count = items.reduce((sum, item) => sum + item.quantity, 0);
    els.cartCount.textContent = count ? `${count} item${count === 1 ? "" : "s"}` : "Empty";

    if (!items.length) {
        const empty = document.createElement("p");
        empty.className = "comment-body";
        empty.textContent = "Add a book to start a cart.";
        els.cartList.append(empty);
    }

    let total = 0;
    for (const item of items) {
        total += item.price * item.quantity;
        const row = document.createElement("div");
        row.className = "cart-item";
        row.innerHTML = `
      <div>
        <strong>${escapeHtml(item.title)}</strong>
        <span>${formatMoney(item.price)} each</span>
      </div>
      <div class="cart-controls">
        <button type="button" aria-label="Decrease ${escapeHtml(item.title)}">-</button>
        <strong>${item.quantity}</strong>
        <button type="button" aria-label="Increase ${escapeHtml(item.title)}">+</button>
      </div>
    `;

        const [decrease, increase] = row.querySelectorAll("button");
        decrease.addEventListener("click", () => updateCartQuantity(item.id, -1));
        increase.addEventListener("click", () => updateCartQuantity(item.id, 1));
        els.cartList.append(row);
    }

    els.cartTotal.textContent = formatMoney(total);
}

// Update cart quantity
function updateCartQuantity(id, delta) {
    const item = state.cart[String(id)];
    if (!item) {
        return;
    }

    item.quantity += delta;
    if (item.quantity <= 0) {
        delete state.cart[String(id)];
    }

    persistCart();
    renderCart();
}

// Filter and sort books
function filteredBooks() {
    const query = els.searchInput.value.trim().toLowerCase();
    const genre = els.genreFilter.value;

    const books = state.books.filter((book) => {
        const haystack = [book.title, book.author, book.genre, book.description]
            .filter(Boolean)
            .join(" ")
            .toLowerCase();
        const matchesQuery = !query || haystack.includes(query);
        const matchesGenre = !genre || book.genre === genre;
        return matchesQuery && matchesGenre;
    });

    const sort = els.sortSelect.value;
    return books.sort((a, b) => {
        if (sort === "priceAsc") return Number(a.price || 0) - Number(b.price || 0);
        if (sort === "priceDesc") return Number(b.price || 0) - Number(a.price || 0);
        if (sort === "newest") return new Date(b.dateWritten || 0) - new Date(a.dateWritten || 0);
        return (a.title || "").localeCompare(b.title || "");
    });
}

// Fill genre dropdown
function populateGenres() {
    const current = els.genreFilter.value;
    const genres = [...new Set(state.books.map((book) => book.genre).filter(Boolean))].sort();
    els.genreFilter.replaceChildren(new Option("All genres", ""));
    for (const genre of genres) {
        els.genreFilter.append(new Option(genre, genre));
    }
    els.genreFilter.value = genres.includes(current) ? current : "";
}

// API helper
async function apiFetch(path, options = {}) {
    const { auth = false, headers, ...fetchOptions } = options;
    const controller = new AbortController();
    const timeoutId = window.setTimeout(() => controller.abort(), 12000);
    const requestHeaders = new Headers(headers || {});

    if (auth) {
        const token = getActiveToken();
        if (!token) {
            throw new Error("Log in again to continue.");
        }
        requestHeaders.set("Authorization", `Bearer ${token}`);
    }

    let response;
    try {
        response = await fetch(`${state.apiBase}${path}`, {
            ...fetchOptions,
            headers: requestHeaders,
            signal: controller.signal
        });
    } catch (error) {
        if (error.name === "AbortError") {
            throw new Error("The API request timed out. Check the API server and database connection.");
        }
        throw error;
    } finally {
        window.clearTimeout(timeoutId);
    }

    const contentType = response.headers.get("content-type") || "";
    const isJson = contentType.includes("application/json");
    const body = isJson ? await response.json() : await response.text();

    if (!response.ok) {
        const message = body?.message || body?.detail || body?.title || body || `Request failed with status ${response.status}`;
        throw new Error(message);
    }

    return body;
}

// Render login status
function renderAuth() {
    const token = getActiveToken();
    const user = state.auth?.user;

    if (token && user) {
        els.authStatus.textContent = `${user.email} - ${user.role}`;
        els.logoutButton.hidden = false;
    } else {
        els.authStatus.textContent = "Signed out";
        els.logoutButton.hidden = true;
    }
}

// Read valid token
function getActiveToken() {
    if (!state.auth?.token) {
        return null;
    }

    if (state.auth.expiresAt && new Date(state.auth.expiresAt).getTime() <= Date.now()) {
        state.auth = null;
        localStorage.removeItem("bookstoreAuth");
        return null;
    }

    return state.auth.token;
}

// Admin check
function isAdmin() {
    return Boolean(getActiveToken() && state.auth?.user?.role === "Admin");
}

// Show status message
function setStatus(message, type = "") {
    els.statusStrip.className = `status-strip ${type}`.trim();
    els.statusStrip.textContent = message;
}

// Local storage helpers
function persistCart() {
    localStorage.setItem("bookstoreCart", JSON.stringify(state.cart));
}

function readCart() {
    try {
        return JSON.parse(localStorage.getItem("bookstoreCart")) || {};
    } catch {
        return {};
    }
}

function readAuth() {
    try {
        return JSON.parse(localStorage.getItem("bookstoreAuth"));
    } catch {
        return null;
    }
}

// Text / display helpers
function normalizeApiBase(value) {
    return (value || window.location.origin).trim().replace(/\/+$/, "");
}

function cleanString(value) {
    const cleaned = String(value || "").trim();
    return cleaned || null;
}

function formatMoney(value) {
    return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD"
    }).format(Number(value || 0));
}

function formatDate(value) {
    if (!value) {
        return "Unknown";
    }

    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
        return "Unknown";
    }

    return new Intl.DateTimeFormat("en-US", {
        year: "numeric",
        month: "short",
        day: "numeric"
    }).format(date);
}

function coverColor(book) {
    const value = `${book.title || ""}${book.author || ""}`;
    const hash = [...value].reduce((sum, char) => sum + char.charCodeAt(0), 0);
    return coverColors[hash % coverColors.length];
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
