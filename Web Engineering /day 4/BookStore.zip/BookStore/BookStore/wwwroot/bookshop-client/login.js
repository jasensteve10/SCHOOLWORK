﻿const btn = document.getElementById("submit");
const form = document.getElementById("loginform");

const emailInpt = document.getElementById("email");
const pwdInpt = document.getElementById("password");
const resultBox = document.getElementById("result");

form.addEventListener('submit', (e) => {
    e.preventDefault();
    resultBox.textContent = "";
    const payload = {
        email: emailInpt.value,
        password: pwdInpt.value

    }

    fetch('https://localhost:7235/api/auth/login', {
        method: "POST",
        headers: {
            "content-type": "application/json"
        },
        body: JSON.stringify(payload)
    }).then((result) => {

        if (result.ok) {
            result.json().then((data) => {
                resultBox.textContent = "You are logged in your token is : " + data.token;
            }).catch(error => {
                resultBox.textContent = error.message;
            });
        }
        else {
            resultBox.textContent = "Invalid Credentials";
        }

        

    }).catch((error) => {
        resultBox.textContent = error.message;

    });
   


});
