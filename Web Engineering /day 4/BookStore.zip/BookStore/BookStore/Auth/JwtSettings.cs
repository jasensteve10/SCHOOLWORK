﻿namespace BookStore.Auth
{
    public class JwtSettings
    {

        public string Issuer { get; set; } = "BookStore";

        public string Audience { get; set; } = "BookStore.Client";

        public string Key { get; set; } = "BookStore-dev-secret-key-change-this-value";

        public int ExpiresMinutes { get; set; } = 120;
    }
}
