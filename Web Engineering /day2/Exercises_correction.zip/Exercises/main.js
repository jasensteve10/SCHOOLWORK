//Exercise 1

document.getElementById("hidebutton").addEventListener('click',()=>{
	if(document.getElementById('ptohide').style.display =="none"){
		document.getElementById('ptohide').style.display="block";
	}
	else{
		document.getElementById('ptohide').style.display="none";
	}
	
});

//Exercise2

document.getElementById("changeColor").addEventListener('click',(e)=>{
	//The target of the  event is the button as the event is fired by the click on the button
	if(e.target.style.backgroundColor=="red"){
		e.target.style.backgroundColor="green";
	}
	else{
		e.target.style.backgroundColor="red";
	}
	
});

//Exercise 3

var abc = "abcdefghijklmnopqrstuvwxyz";
var index =0;

document.getElementById('addLetter').addEventListener('click',addLetter);
document.getElementById('reset').addEventListener('click',reset);

function addLetter(){
	let elem = document.getElementById('abc');
	elem.innerHTML+=abc[index];
	index++;
	if( index == abc.length){
		index=0;
	}
}

function reset(){
	let elem = document.getElementById('abc');
	elem.innerHTML='';
	index =0;
}