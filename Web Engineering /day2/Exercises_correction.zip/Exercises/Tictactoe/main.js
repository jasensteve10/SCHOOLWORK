var player =1;
var running =true;

var game = [[0,0,0]
		   ,[0,0,0],
		   	[0,0,0]];

const cells =document.getElementsByClassName('cell');

for(let i = 0; i< cells.length; ++i){
	cells[i].addEventListener('click',CellClick);
}

document.getElementById('reset').addEventListener('click',reset);

// return 1 (p1 win) 2 (p2 win) 0(=draw) -1 game continue
function isGameOver(){
	//check winner
	if(game[0][0]!=0 && ((game[0][0] === game[0][1]) && (game[0][0]== game[0][2]))){
		return game[0][0];
	}
	else if(game[1][0]!=0 && ((game[1][0] === game[1][1]) && (game[1][0]== game[2][0]))){
		return game[1][0];
	}
	else if(game[2][0]!=0 && ((game[2][0] === game[2][1]) && (game[2][0]== game[2][2]))){
		return game[2][0];
	}
	else if(game[0][0]!=0 && ((game[0][0] === game[1][0]) && (game[0][0]== game[2][0]))){
		return game[1][0];
	}
	else if(game[0][1]!=0 && ((game[0][1] === game[1][1]) && (game[0][1]== game[2][1]))){
		return game[0][1];
	}
	else if(game[0][2]!=0 && ((game[0][2] === game[1][2]) && (game[0][2]== game[2][2]))){
		return game[0][2];
	}
	else if(game[0][0]!=0 && ((game[0][0] === game[1][1]) && (game[0][0]== game[2][2]))){
		return game[0][0];
	}
	else if(game[0][2]!=0 && ((game[0][2] === game[1][1]) && (game[0][2]== game[2][0]))){
		return game[0][2];
	}
	else{
		for (let i =0; i< game.length; i++){
			for(let j = 0; j < game[i].length; j++){
				if(game[i][j] == 0){
					//Game continue all cells are not fillled
					return -1
				}
			}
		}
	}
	//Draws
	return 0;

}

function NextPlayer(){
	if(player ==1){
		player=2;
	}
	else{
		player =1;
	}
}

function reset(){
	game=[[0,0,0],[0,0,0],[0,0,0]];
	for(let i = 0; i< cells.length; i++){
		cells[i].innerHTML="";
	}
	document.getElementById('result').innerHTML="";
	player=1;
	running=true;

}

function CellClick(event){
	if(!running){
		return;
	}
	let target = event.target;


	let symbol ='x';
	if( player == 2){
		symbol='o';
	}

	//cell_0_1 =>["cell","0","1"];
	let id = target.id.split('_');
	let x = id[1];
	let y = id[2]

	//if cell is empty
	if(game[x][y]==0){
		target.innerHTML=symbol;
		game[x][y]=player;
	}
	else{
		return;
	}

	let result = isGameOver();

	if(result ==-1){
		NextPlayer();
	}
	else{
		running=false;

		var resultBox = document.getElementById('result');

		if(result !=0 ){
			resultBox.innerHTML=`Player ${result} Win !`;
		}
		else{
			resultBox.innerHTML="It's a Draw !";
		}
	}
}