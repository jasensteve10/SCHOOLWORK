document.addEventListener("DOMContentLoaded",()=>{
//When dom loaded I load the saved tasks

const localStorageKey='kanbanTasks';
const form= document.getElementById("new-task-form");
const input = document.getElementById('task-input');

const lists = document.querySelectorAll('.task-list');
loadTask();

function createTaskElement(text){
	const div =document.createElement('div');//create <div></div>
	div.classList.add('task');
	div.innerHTML=`<h3>${text}</h3>`;
	div.draggable=true;

	const deleteBtn = document.createElement('button');
	deleteBtn.className='delete-btn'; // overwrite the class="" attribute
	deleteBtn.textContent='x';

	deleteBtn.addEventListener('click',(e)=>{
		e.stopPropagation();
		const fromStatus = div.closest('.task-list').dataset.status;
		if(fromStatus !=='canceled')return;
		div.remove();
		saveTasks();
	})

	//add deletebtn to the end of task element
	div.appendChild(deleteBtn);

	//Envent for task & delete btn

	div.addEventListener('dragstart',()=>{
		div.classList.add('dragging');
	});

	div.addEventListener('dragend',()=>{
		div.classList.remove('dragging');
	});


	return div;
}

function saveTasks(){
	const data={}

	/*
		{
			'todo': [...],
			'wip': [...],
			'done': [...],
			'canceled': [...],
		}

	*/

	lists.forEach(list=>{
		const status = list.dataset.status;
		//Take the text content of each task element remove the x from btn and add it to the right array in data
		data[status]=Array.from(list.children).map(task=>task.textContent.replace('x','').trim());
	});
	//Save my object in JSON in local storage (key / value (string))
	localStorage.setItem(localStorageKey,JSON.stringify(data));
}

function loadTask(){
	//Get the data from the local storage (json string) and parse it
	const data = JSON.parse(localStorage.getItem(localStorageKey));
	//No empty save
	if(!data)return;

	//For each element of my object do as status and list
	/*
		[
			['todo',[...]],
			['in-progress',[...]],
			['todo',[...]],
			['canceled',[...]]
		]
	*/
	Object.entries(data).forEach(([status,tasks])=>{
		const list = document.querySelector(`#${status} .task-list`);
		tasks.forEach(text=>{
			const task = createTaskElement(text);
			list.appendChild(task);
		});
	});

}

form.addEventListener('submit',(e)=>{
	e.preventDefault();// prevent the form to  be submitted.

	const text = input.value.trim();//trim remove trailing space
	//if text is null stop function
	if(!text)return;

	const task =createTaskElement(text);
	document.querySelector("#todo .task-list").appendChild(task);
	saveTasks();
});

lists.forEach(list=>{
	list.addEventListener('dragover',(e)=>{
		e.preventDefault();
		const dragging =document.querySelector('.dragging');
		const fromStatus = dragging.closest('.task-list').dataset.status;
		const toStatus = list.dataset.status;

		//No possibility to go from todo to done.
		if(fromStatus==='todo' && toStatus === 'done') return;
		list.classList.add('drag-over');
	});

	list.addEventListener('dragleave',(e)=>{
		e.preventDefault();
		list.classList.remove('drag-over');
	});

	list.addEventListener('drop',(e)=>{
		e.preventDefault();
		const dragging =document.querySelector('.dragging');
		const fromStatus = dragging.closest('.task-list').dataset.status;
		const toStatus = list.dataset.status;
		list.classList.remove('drag-over');

		if(fromStatus === 'todo' && toStatus === 'done')return;
		list.appendChild(dragging);
		saveTasks();

	})
});


});