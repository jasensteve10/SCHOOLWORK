document.addEventListener('DOMContentLoaded',()=>{
	console.log("my Dom has loaded.");
	//Select By Id
let mainTitle= document.getElementById("main-title");
console.log(mainTitle);

//Select every elements matching a class
let containers= document.getElementsByClassName('container');
console.log(containers);

//Select every elements matching a tag
let lis= document.getElementsByTagName("li");
console.log(lis);

//Select every element matching a query (using css selector)
let domlis = document.querySelectorAll("#Dom-container li");
console.log(domlis);

//Select only first element matching a query
let firstdomli = document.querySelector("#Dom-container li");
console.log(firstdomli);

//Modifying Element innerHTML (so you can include HTML)
mainTitle.innerHTML="Dom <span style=\"color:red\">Manipulated</span>";
//Only Text you can't include html inside
mainTitle.textContent="Dom <span style=\"color:red\">Manipulated</span>";

mainTitle.style.color="#333";
// CSS it's background-color => backgroundColor
mainTitle.style.backgroundColor="#ececec"

//Class Manipulation

let itemToChange = document.getElementById("itemtochange");
itemToChange.classList.remove("notVisible");
itemToChange.classList.add("visible");


//Square animation example
const square = document.querySelector('.square');
//The .loader element
const loader = square.parentElement;
let pos =0;
let direction=1;
let run =false;
function animateSquare(){
	pos+=direction*2;
	//loader width - square width
	console.log((loader.offsetWidth - square.offsetWidth));
	if( pos >= (loader.offsetWidth - square.offsetWidth) || pos <=0){
		direction*=-1;
	}
	square.style.left = pos +"px";
	//request to call a function on the next refresh rate of the browser (smoother animation)
	if(run){
		requestAnimationFrame(animateSquare);
	}
	
}
let start_btn = document.getElementById('start_event');
start_btn.addEventListener('click',(e)=>{
	//e represent the event object
	//this function preventDefaultBehavior of an object for this event (here click)
	e.preventDefault();
	if(run){
		start_btn.textContent="Start Animation";
		run=false;
	}
	else{
		start_btn.textContent="Stop Animation";
		run =true;
		animateSquare();
	}
	start_btn.classList.toggle("danger");
});

let x=0;
loader.addEventListener("wheel",(evt)=>{
	evt.preventDefault();
	const boxWidth = loader.clientWidth;
	const squareWidth = square.offsetWidth;
	x+= evt.deltaY *0.3;

	if(x<0) x=0;
	if(x>boxWidth - squareWidth ){
		x= boxWidth -squareWidth;
	}
	square.style.left=x+"px";

});

//WORK with selector of multiple element your add event listener should be in a loop
for(const li of domlis){
	li.addEventListener("click",(evt)=>{
		//Element that trigger the event (could be en aelement inside the binded element)
		console.log(evt.target);
		//The element with the envet binded on
		console.log(evt.currentTarget);
		console.log("Click");
	});
}

});



