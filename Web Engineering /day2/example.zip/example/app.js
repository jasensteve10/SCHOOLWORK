//for loop
let a=0;
for(let i=0; i<10; i+=2){
	console.log(i);
}

//Only syntax (use a for for this)
while(a<5){
	/*
	 ++a => increment then return the value
	 a++ => return the value then increment
	*/
	console.log(a++);
}

// Boolean expression

let b_c1= true;
let b_c2= false;
let x1=5;
let x2="5"

if(x1 === x2){
	console.log("IF");
}
else if(b_c1 || b_c2){
	console.log("else if");
}
else if( (x1 == x2) && b_c1	){
	console.log("else if");
}

/*
		== equal
		!= different
		=== strictly equal
		!== strictly different (type checking)
		> greater
		< lower
		=> greater or equal
		<= lower or equal
		|| or
		&& and
		! negation
*/

// Switch case

let word ="Hello";

switch(word){
		case "Hello":
			console.log("ok");
			break;
		case "World":
			console.log("world");
			break;
		default:
			console.log("not ok");
			break;
}

function Add(a,b=2){
	return a+b;
}

let res_add = Add(2,5); // 2+5=7;
console.log(res_add	);

res_add=Add(7); //7+2=9

console.log(res_add)

async function AddA(a,b=2){
	return a+b;
}

res_add = AddA(2+5);// This function doesn't return 7 but a promise
console.log(res_add)
res_add.then(value=>{
	console.log(value);
});

//Only usable in async function not at the root level
//let other_promise_result= await AddA(7,9);
//Result of the promise (waited)
//console.log(other_promise_result);

//Array

//Empty Array
let myArr=[];
//predefined array
//myArr=[1,2,3,4,5,6];
//Multiple type in array is ok
myArr=["test",1,1.5,2,"hello"];
//Array will be [2,2,3,4,5,6]
myArr[0]=2;

//Add element at the end
myArr.push(3);

//You can use a for loop
console.log("Simple for");
for(let i=0; i < myArr.length; i++){
	//Allow me to modify array value
	console.log(myArr[i]);
}

console.log("Foreach");
//Foreach loop read only
// in instead of of if you want index
for(const elem of myArr){
	console.log(elem);
}

//Another way to make a foreach
console.log("Another Foreach");
myArr.forEach(elem=> console.log(elem));

//Multi dimensional array (2d array)
let mdArr=[[1,"test",2],["test",1,3]];

//Object
const myObj ={
	"firstname":"Clément",
	"lastname":"Ziane",
	"email" : "clement.ziane@dsti.institute"
}

console.log(myObj["firstname"]);
console.log(myObj.lastname);
myObj.present=function(){
	console.log(`My name is ${this.firstname} ${this.lastname}`);
}

//myObj.present();