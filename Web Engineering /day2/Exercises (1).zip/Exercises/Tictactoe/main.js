var player =1;
var running =true;

var game = [[0,0,0],[0,0,0],[0,0,0]];

const cells =document.getElementsByClassName('cell');

for(let i = 0; i< cells.length; ++i){
	cells[i].addEventListener('click',CellClick);
}

document.getElementById('reset').addEventListener('click',reset);


function isGameOver(){
	
}

function NextPlayer(){
	
}

function reset(){
		

}

function CellClick(event){

}